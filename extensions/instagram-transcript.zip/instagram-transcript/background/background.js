const FREE_LIMIT = 2;
const WEBSITE_URL = 'https://transcripthub.net';

// 获取总计使用次数
async function getTotalUsage() {
  const data = await chrome.storage.local.get(['usageCount']);
  return data.usageCount || 0;
}

// 增加使用次数
async function incrementUsage() {
  const count = await getTotalUsage();
  await chrome.storage.local.set({ usageCount: count + 1 });
  return count + 1;
}

// 检查是否可以免费使用
async function canUseFree() {
  const count = await getTotalUsage();
  return count < FREE_LIMIT;
}

// 监听来自popup和content的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  (async () => {
    try {
      if (request.action === 'checkQuota') {
        const count = await getTotalUsage();
        const canUse = count < FREE_LIMIT;
        sendResponse({
          success: true,
          used: count,
          limit: FREE_LIMIT,
          canUse
        });
        return;
      }

      if (request.action === 'incrementUsage') {
        const count = await incrementUsage();
        const remaining = Math.max(0, FREE_LIMIT - count);
        sendResponse({ success: true, remaining });
        return;
      }

      if (request.action === 'openWebsite') {
        const url = request.url
          ? `${WEBSITE_URL}/instagram-transcript?url=${encodeURIComponent(request.url)}`
          : WEBSITE_URL;
        await chrome.tabs.create({ url, active: true });
        sendResponse({ success: true });
        return;
      }
    } catch (error) {
      sendResponse({
        success: false,
        error: 'unknown',
        message: error.message
      });
    }
  })();

  return true;
});
